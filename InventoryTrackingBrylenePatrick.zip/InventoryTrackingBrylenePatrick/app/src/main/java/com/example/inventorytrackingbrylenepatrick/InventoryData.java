package com.example.inventorytrackingbrylenepatrick;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class InventoryData extends SQLiteOpenHelper {

    // Define the database version and name
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "inventory.db";

    // Singleton instance of InventoryDatabase
    private static InventoryData invData;

    // Enumeration for sorting inventory items
    public enum InventorySortOrder {ALPHABETIC, UPDATE_DESC, UPDATE_ASC}

    // Method to get the singleton instance of InventoryDatabase
    public static InventoryData getInstance(Context context) {
        if (invData == null) {
            invData = new InventoryData(context);
        }
        return invData;
    }

    // Constructor for InventoryDatabase
    private InventoryData(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    // Define table and column names for login table
    private static final class LoginsTable {
        private static final String TABLE = "logins";
        private static final String COL_ID = "_id";
        private static final String COL_USER = "username";
        private static final String COL_PASSWORD = "password";
    }

    // Define table and column names for items table
    private static final class ItemsTable {
        private static final String TABLE = "items";
        private static final String COL_NAME = "item_name";
        private static final String COL_DESC = "item_description";
        private static final String COL_QTY = "quantity";
    }

    // Method to create the database tables
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create logins table
        db.execSQL("CREATE TABLE " + LoginsTable.TABLE + " (" +
                LoginsTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                LoginsTable.COL_USER + " TEXT," +
                LoginsTable.COL_PASSWORD + " TEXT)");

        // Create items table
        db.execSQL("CREATE TABLE " + ItemsTable.TABLE + " (" +
                ItemsTable.COL_NAME + " TEXT PRIMARY KEY," +
                ItemsTable.COL_DESC + " TEXT," +
                ItemsTable.COL_QTY + " TEXT)");

        // Add default example items to the table's if wanted
        //--------------
    }

    // Method to upgrade the database tables
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // Drop the existing tables
        db.execSQL("DROP TABLE IF EXISTS " + LoginsTable.TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + ItemsTable.TABLE);

        // Recreate the tables
        onCreate(db);
    }

    // Methods for managing inventory items------------------------------------------------------

    // Method to get the list of inventory items
    public List<ItemData> getItems(InventorySortOrder order) {
        List<ItemData> items = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        // Sort the items based on the selected order
        String orderBy;
        switch (order) {
            case ALPHABETIC:
                orderBy = ItemsTable.COL_NAME + " COLLATE NOCASE";
                break;
            case UPDATE_DESC:
                orderBy = ItemsTable.COL_QTY + " DESC";
                break;
            default:
                orderBy = ItemsTable.COL_QTY + " ASC";
                break;
        }

        // Query the items table
        String sql = "SELECT * FROM " + ItemsTable.TABLE + " ORDER BY " + orderBy;
        Cursor cursor = db.rawQuery(sql, null);

        // Iterate through the cursor and add items to the list
        if (cursor.moveToFirst()) {
            do {
                // Create a new item object
                ItemData item = new ItemData();

                // Set the item's values
                item.setName(cursor.getString(0));
                item.setDesc(cursor.getString(1));
                item.setQty(cursor.getString(2));

                // Add the item to the list
                items.add(item);
            } while (cursor.moveToNext());
        }

        // Close the cursor and database connection
        cursor.close();
        db.close();

        // Return the list of items
        return items;
    }

    // Method to add a new inventory item
    public void addItem(ItemData item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ItemsTable.COL_NAME, item.getName());
        values.put(ItemsTable.COL_DESC, item.getDesc());
        values.put(ItemsTable.COL_QTY, item.getQty());

        db.insert(ItemsTable.TABLE, null, values);
        db.close();
    }

    // Method to update an existing inventory item
    public void updateItem(ItemData item) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(ItemsTable.COL_DESC, item.getDesc());
        values.put(ItemsTable.COL_QTY, item.getQty());

        db.update(ItemsTable.TABLE, values, ItemsTable.COL_NAME + " = ?",
                new String[]{item.getName()});

        db.close();
    }

    // Method to delete an inventory item
    public void deleteItem(ItemData item) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(ItemsTable.TABLE, ItemsTable.COL_NAME + " = ?",
                new String[]{item.getName()});
        db.close();
    }

// Methods for managing login information------------------------------------------------------

    // Method to add a new login entry
    public void addLogin(UserInfo user) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(LoginsTable.COL_USER, user.getUser());
        values.put(LoginsTable.COL_PASSWORD, user.getPassword());

        db.insert(LoginsTable.TABLE, null, values);

        db.close();
    }

    // Method to check if a login entry exists
    public boolean checkUser(UserInfo user) {
        // Get a readable database instance
        SQLiteDatabase db = getReadableDatabase();

        // Define the columns to return
        String[] projection = {LoginsTable.COL_USER, LoginsTable.COL_PASSWORD};

        // Define the WHERE clause and its arguments
        String selection = LoginsTable.COL_USER + " = ?";
        String[] selectionArgs = {user.getUser()};

        // Define the sort order
        String sortOrder = LoginsTable.COL_ID + " DESC";

        // Execute the query and get the cursor
        try (Cursor cursor = db.query(LoginsTable.TABLE, projection, selection, selectionArgs, null, null, sortOrder)) {
            // Check if the cursor has any rows
            if (cursor.moveToFirst()) {
                // Get the user's password from the cursor
                String password = cursor.getString(cursor.getColumnIndexOrThrow(LoginsTable.COL_PASSWORD));
                // Compare the user's password with the provided one
                return password.equals(user.getPassword());
            } else {
                // No rows found, user not in the database
                return false;
            }
        }
    }

}
