package com.example.inventorytrackingbrylenepatrick;

public class UserInfo {
    // Instance variables
    private long id; // Using camelCase naming convention
    private String userName;
    private String password;

    // Default constructor
    public UserInfo(){}

    // Setter methods
    public void setId(long id){
        this.id = id; // Assigning the parameter to the instance variable
    }

    public void setUser(String user){
        this.userName = user; // Assigning the parameter to the instance variable
    }

    public void setPass(String pass){
        this.password = pass; // Assigning the parameter to the instance variable
    }

    // Getter methods
    public String getUser(){
        return userName; // Return the value of the instance variable
    }

    public String getPassword(){
        return password; // Return the value of the instance variable
    }

    public long getId() {
        return id; // Return the value of the instance variable
    }
}
