package com.example.inventorytrackingbrylenepatrick;

public class ItemData {
    private String name;
    private String description;
    private String quantity;

    public ItemData(){}

    // setter methods
    public void setName(String name){
        this.name = name;
    }

    public void setDesc(String desc){
        this.description = desc;
    }

    public void setQty(String qty){
        this.quantity = qty;
    }

    // getter methods
    public String getName(){
        return name;
    }

    public String getDesc(){
        return description;
    }

    public String getQty(){
        return quantity;
    }

}

