package com.example.inventorytrackingbrylenepatrick;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class NewInventory extends AppCompatActivity {

    // Declare instance variables
    private InventoryData mInvDb;
    private TextView nameEntry, descEntry, qtyEntry;
    private Button submitButton;
    private Intent gridIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_inventory);

        // Initialize the inventory database instance
        mInvDb = InventoryData.getInstance(getApplicationContext());

        // Create an intent for the grid display activity
        gridIntent = new Intent(this, GridDisplay.class);

        // Get references to the text views in the layout
        nameEntry = findViewById(R.id.item_name);
        descEntry = findViewById(R.id.description);
        qtyEntry = findViewById(R.id.itemQuantity);

        // Get reference to the submit button in the layout
        submitButton = findViewById(R.id.addButton);

        // Set a click listener on the submit button
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Create a new item object
                ItemData newItem = new ItemData();

                // Set the name, description, and quantity fields of the item object
                newItem.setName(nameEntry.getText().toString());
                newItem.setDesc(descEntry.getText().toString());
                newItem.setQty(qtyEntry.getText().toString());

                // Add the new item to the database
                mInvDb.addItem(newItem);

                // Show a toast message to indicate that a new item has been added
                Toast.makeText(getApplicationContext(), "New Item Added!", Toast.LENGTH_LONG).show();

                // Start the grid display activity
                startActivity(gridIntent);
            }
        });
    }
}
