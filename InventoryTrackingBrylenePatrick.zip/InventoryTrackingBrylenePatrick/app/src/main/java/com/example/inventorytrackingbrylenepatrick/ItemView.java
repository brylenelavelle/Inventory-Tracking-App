package com.example.inventorytrackingbrylenepatrick;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ItemView extends AppCompatActivity implements View.OnClickListener {

    private InventoryData invData; // instance of the InventoryDatabase class

    private TextView itemName, itemValue, quanVal, phoneView; // text views to display and manipulate data

    @Override
    protected void onCreate(Bundle savedInstanceState)  {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_view);

        // load the database
        invData = InventoryData.getInstance(getApplicationContext());

        // define variables needed
        String name, description, qty;
        boolean stockNotify = false;

        // get the extras from grid activity
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();

        // store the values from the bundle
        name = extras.getString("NAME");
        description = extras.getString("DESC");
        qty = extras.getString("QTY");

        // set and update text views
        itemName = findViewById(R.id.itemName);
        itemValue = findViewById(R.id.itemValue);
        quanVal = findViewById(R.id.quanVal);

        itemName.setText(name);
        itemValue.setText(description);
        quanVal.setText(qty);

        // set up buttons
        Button saveButton = findViewById(R.id.saveButton);
        ImageButton subtract = findViewById(R.id.subtract);
        ImageButton plus = findViewById(R.id.plus);
        ImageButton trash = findViewById(R.id.deleteItem);

        // button listeners
        saveButton.setOnClickListener(this);
        subtract.setOnClickListener(this);
        plus.setOnClickListener(this);
        trash.setOnClickListener(this);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.saveButton:
                // create an item object
                ItemData update = new ItemData();
                // set text views
                itemName = findViewById(R.id.itemName);
                itemValue = findViewById(R.id.itemValue);
                quanVal = findViewById(R.id.quanVal);
                // update item with text view values
                update.setName(itemName.getText().toString());
                update.setDesc(itemValue.getText().toString());
                update.setQty(quanVal.getText().toString());
                // update the database with the new item data
                invData.updateItem(update);
                Toast.makeText(getApplicationContext(),"Changes Saved!",
                        Toast.LENGTH_LONG).show();
                // start the grid display intent
                Intent mIntent = new Intent(this, GridDisplay.class);
                startActivity(mIntent);
                break;
            case R.id.subtract:
                // get the qty to subtract 1 from
                int updateQty = Integer.parseInt(quanVal.getText().toString());
                updateQty--;
                // update the text view
                quanVal.setText(String.valueOf(updateQty));
                // create an item to update the database
                ItemData minusUpdate = new ItemData();
                minusUpdate.setQty(String.valueOf(updateQty));
                minusUpdate.setDesc(itemValue.getText().toString());
                minusUpdate.setName(itemName.getText().toString());
                // update the database with the new item data
                invData.updateItem(minusUpdate);
                break;
            case R.id.plus:
                // get the qty to add 1 to
                updateQty = Integer.parseInt(quanVal.getText().toString());
                updateQty++;
                // update the text view
                quanVal.setText(String.valueOf(updateQty));
                // create an item to update the database
                ItemData plusUpdate = new ItemData();
                plusUpdate.setQty(String.valueOf(updateQty));
                plusUpdate.setDesc(itemValue.getText().toString());
                plusUpdate.setName(itemName.getText().toString());
                // update the database with the new item data
                invData.updateItem(plusUpdate);
                break;
            case R.id.deleteItem:
                // create the item to delete
                ItemData deleteItem = new ItemData();

                // set the item values
                itemName = findViewById(R.id.itemName);
                itemValue = findViewById(R.id.itemValue);
                quanVal = findViewById(R.id.quanVal);
                deleteItem.setName(itemName.getText().toString());
                deleteItem.setDesc(itemValue.getText().toString());
                deleteItem.setQty(quanVal.getText().toString());
                // delete the item from the database
                invData.deleteItem(deleteItem);
                Toast.makeText(getApplicationContext(),"Item Deleted!",
                        Toast.LENGTH_LONG).show();
                // start the grid display intent
                Intent deleteIntent = new Intent(this, GridDisplay.class);
                startActivity(deleteIntent);
                break;
            default:
                break;
        }
    }
}
