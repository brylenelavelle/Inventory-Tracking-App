package com.example.inventorytrackingbrylenepatrick;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    // declare variables
    private InventoryData invData;
    private TextView userText;
    private TextView pass;
    private Button loginButton;
    private Button registerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // load the database
        invData = InventoryData.getInstance(getApplicationContext());

        // setup login buttons
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.newUserButton);

        // set click listeners for buttons
        loginButton.setOnClickListener(this);
        registerButton.setOnClickListener(this);

        // setup views
        userText = findViewById(R.id.username);
        pass = findViewById(R.id.password);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View view) {
        UserInfo tempUser = new UserInfo();

        // check which button was clicked
        switch (view.getId()) {
            case R.id.loginButton:
                // create a temp user with entered credentials
                tempUser.setUser(userText.getText().toString());
                tempUser.setPass(pass.getText().toString());

                // check the user against the database
                if (invData.checkUser(tempUser)){
                    // if login is successful, show success message
                    Toast.makeText(getApplicationContext(),"Successful login!"
                            , Toast.LENGTH_LONG).show();

                    // proceed to inventory dashboard
                    // create intent for Inventory Activity
                    Intent intent = new Intent(this, GridDisplay.class);
                    // start Inventory Activity
                    startActivity(intent);
                }
                else {
                    // if login is unsuccessful, show error message
                    Toast.makeText(getApplicationContext(),"Login credentials are invalid, " +
                            "please try again.", Toast.LENGTH_LONG).show();
                }
                break;
            case R.id.newUserButton:
                // create the new user with entered credentials
                tempUser.setUser(userText.getText().toString());
                tempUser.setPass(pass.getText().toString());

                // add the new user to the database
                invData.addLogin(tempUser);
                break;
        }
    }
}
