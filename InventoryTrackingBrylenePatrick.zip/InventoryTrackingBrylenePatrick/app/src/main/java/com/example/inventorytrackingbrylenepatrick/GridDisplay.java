package com.example.inventorytrackingbrylenepatrick;

import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class GridDisplay extends AppCompatActivity {

    // Declare instance variables for intent to start activities
    private Intent newItemIntent, itemViewIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_display);

        // Get reference to grid container in layout
        GridLayout gridContainer = findViewById(R.id.gridContainer);

        // Create an intent to start ItemViewActivity
        itemViewIntent = new Intent(this, ItemData.class);

        // Load list of current items from the database
        List<ItemData> items = InventoryData.getInstance(getApplicationContext()).getItems(InventoryData.InventorySortOrder.ALPHABETIC);

        // Add buttons to grid for each item
        for (ItemData item: items) {
            Button itemButton = new Button(getApplicationContext());
            itemButton.setText(item.getName());
            itemButton.setOnClickListener(view -> {
                // Pass item data as extras to itemViewIntent
                Intent intent = new Intent(this, ItemView.class);
                intent.putExtra("NAME", item.getName());
                intent.putExtra("DESC", item.getDesc());
                intent.putExtra("QTY", item.getQty());
                startActivity(intent);
            });
            gridContainer.addView(itemButton);
        }

        // Create an intent to start NewItemActivity
        newItemIntent = new Intent(this, NewInventory.class);

        // Get reference to FAB and set click listener to start newItemIntent
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(view -> startActivity(newItemIntent));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.bar_menu, menu);
        return true;
    }
}

